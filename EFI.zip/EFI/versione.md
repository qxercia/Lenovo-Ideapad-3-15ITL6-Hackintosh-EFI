---------------
OpenCore: 0.7.1
Github EFI: https://github.com/nurdiny13/LENOVO-IDEAPAD-GAMING-3i-Hackintosh-Opencore
---------------
